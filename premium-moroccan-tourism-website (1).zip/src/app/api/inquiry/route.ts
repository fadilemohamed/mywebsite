import { db } from "@/db";
import { inquiries, tours } from "@/db/schema";
import { NextRequest } from "next/server";
import { z } from "zod";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

const schema = z.object({
  fullName: z.string().min(2),
  email: z.string().email(),
  phone: z.string().optional().nullable(),
  whatsapp: z.string().optional().nullable(),
  startDate: z.string().optional().nullable(),
  endDate: z.string().optional().nullable(),
  travelers: z.coerce.number().int().min(1).optional(),
  destinations: z.union([z.array(z.string()), z.string()]).optional(),
  activities: z.union([z.array(z.string()), z.string()]).optional(),
  budgetRange: z.string().optional().nullable(),
  groupType: z.string().optional().nullable(),
  language: z.string().optional().nullable(),
  additional: z.string().optional().nullable(),
  tour: z.string().optional().nullable(),
});

export async function POST(req: NextRequest) {
  let body: any = {};
  const contentType = req.headers.get("content-type") || "";
  if (contentType.includes("application/json")) {
    body = await req.json();
  } else if (contentType.includes("application/x-www-form-urlencoded") || contentType.includes("multipart/form-data")) {
    const form = await req.formData();
    Object.fromEntries(form.entries());
    body = Object.fromEntries(form.entries());
  } else {
    try { body = await req.json(); } catch { body = {}; }
  }

  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return Response.json({ ok: false, error: parsed.error.flatten() }, { status: 400 });
  }

  const v = parsed.data;
  let tourId: number | null = null;
  if (v.tour) {
    const [t] = await db.select().from(tours).where(eq(tours.slug, v.tour)).limit(1);
    if (t) tourId = t.id as any;
  }

  await db.insert(inquiries).values({
    fullName: v.fullName,
    email: v.email,
    phone: v.phone || null,
    whatsapp: v.whatsapp || null,
    startDate: v.startDate ? new Date(v.startDate) as any : null,
    endDate: v.endDate ? new Date(v.endDate) as any : null,
    travelers: v.travelers || 2,
    destinations: Array.isArray(v.destinations) ? v.destinations : (v.destinations ? [v.destinations] : null),
    activities: Array.isArray(v.activities) ? v.activities : (v.activities ? [v.activities] : null),
    budgetRange: v.budgetRange || null,
    groupType: v.groupType || null,
    language: v.language || null,
    additional: v.additional || null,
    tourId: tourId || null,
    source: "website",
  });

  // If emailing is desired, integrate a provider here. For now, we return success only.
  return Response.json({ ok: true });
}
