import { db } from "@/db";
import { tours } from "@/db/schema";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { TourCard } from "@/components/site/TourCard";

export const dynamic = "force-dynamic";

export default async function ToursPage({ searchParams }: { searchParams: { dest?: string; type?: string; duration?: string; lang?: string } }) {
  // simple filters: type=private|group, duration=1|2-3|4+
  // We implement filtering on the server after fetching seed data for simplicity.
  let rows = await db.select().from(tours);
  if (searchParams.type === "private") rows = rows.filter((t: any) => t.isPrivate);
  if (searchParams.type === "group") rows = rows.filter((t: any) => t.isGroup);
  if (searchParams.duration === "1") rows = rows.filter((t: any) => t.durationDays === 1);
  if (searchParams.duration === "2-3") rows = rows.filter((t: any) => t.durationDays >= 2 && t.durationDays <= 3);
  if (searchParams.duration === "4+") rows = rows.filter((t: any) => t.durationDays >= 4);
  return (
    <main className="body-gradient min-h-dvh">
      <Navbar />
      <section className="mx-auto container-max px-6 py-12">
        <h1 className="h2 text-4xl font-semibold">Tours & Excursions</h1>
        <p className="mt-2 text-stone-700">Private and group options in multiple languages. Prices are placeholders until confirmed.</p>

        <form className="mt-6 grid gap-3 md:grid-cols-4" action="/tours" method="get">
          <label className="grid gap-1 text-sm">
            <span>Destination</span>
            <input className="rounded-xl border px-3 py-2" name="dest" placeholder="e.g., marrakech" defaultValue={searchParams.dest || ""} />
          </label>
          <label className="grid gap-1 text-sm">
            <span>Type</span>
            <select className="rounded-xl border px-3 py-2" name="type" defaultValue={searchParams.type || ""}>
              <option value="">Any</option>
              <option value="private">Private</option>
              <option value="group">Group</option>
            </select>
          </label>
          <label className="grid gap-1 text-sm">
            <span>Duration</span>
            <select className="rounded-xl border px-3 py-2" name="duration" defaultValue={searchParams.duration || ""}>
              <option value="">Any</option>
              <option value="1">1 day</option>
              <option value="2-3">2–3 days</option>
              <option value="4+">4+ days</option>
            </select>
          </label>
          <div className="grid items-end">
            <button className="btn-secondary" type="submit">Filter</button>
          </div>
        </form>

        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {rows
            .filter((t) => !searchParams.dest || t.destinationSlug === searchParams.dest)
            .filter((t) => !searchParams.type || (searchParams.type === "private" ? t.isPrivate : t.isGroup))
            .filter((t) => {
              const d = t.durationDays;
              if (!searchParams.duration) return true;
              if (searchParams.duration === "1") return d === 1;
              if (searchParams.duration === "2-3") return d >= 2 && d <= 3;
              if (searchParams.duration === "4+") return d >= 4;
              return true;
            })
            .map((t) => (
              <TourCard key={t.slug} t={t as any} />
            ))}
        </div>
      </section>
      <Footer />
    </main>
  );
}
