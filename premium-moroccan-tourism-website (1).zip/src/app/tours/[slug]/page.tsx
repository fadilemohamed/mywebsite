import { db } from "@/db";
import { tours } from "@/db/schema";
import { eq } from "drizzle-orm";
import Image from "next/image";
import Link from "next/link";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";

export const dynamic = "force-dynamic";

export default async function TourDetail({ params }: { params: { slug: string } }) {
  const [t] = await db.select().from(tours).where(eq(tours.slug, params.slug)).limit(1);
  if (!t) {
    return (
      <main>
        <Navbar />
        <div className="mx-auto container-max px-6 py-20">
          <h1 className="h2 text-3xl font-semibold">Tour not found</h1>
        </div>
        <Footer />
      </main>
    );
  }

  return (
    <main className="min-h-dvh body-gradient">
      <Navbar />
      <section className="relative h-[40svh]">
        <Image src={t.mainImage || "/images/marrakech-medina.jpg"} alt={t.name} fill className="object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-black/10" />
        <div className="relative z-10 mx-auto container-max px-6 h-full flex items-end pb-8">
          <div>
            <h1 className="h1 text-4xl md:text-5xl font-bold text-white">{t.name}</h1>
            <p className="mt-2 text-white/90">Duration: {t.durationDays} days</p>
          </div>
        </div>
      </section>

      <section className="mx-auto container-max px-6 py-12 grid gap-10 md:grid-cols-3">
        <article className="md:col-span-2 grid gap-6">
          {Array.isArray(t.highlights) && t.highlights?.length > 0 && (
            <div>
              <h3 className="font-semibold text-xl">Highlights</h3>
              <ul className="mt-2 grid gap-1 list-disc pl-5 text-stone-700">
                {t.highlights.map((h: string, i: number) => (
                  <li key={i}>{h}</li>
                ))}
              </ul>
            </div>
          )}

          {Array.isArray(t.itinerary) && t.itinerary?.length > 0 && (
            <div>
              <h3 className="font-semibold text-xl">Itinerary</h3>
              <ol className="mt-2 grid gap-3">
                {t.itinerary.map((d: any, i: number) => (
                  <li key={i} className="card p-4">
                    <div className="font-medium">Day {d.day}: {d.title}</div>
                    <p className="text-sm text-stone-700">{d.details}</p>
                  </li>
                ))}
              </ol>
            </div>
          )}

          <div>
            <h3 className="font-semibold text-xl">What's included</h3>
            <ul className="mt-2 grid gap-1 list-disc pl-5 text-stone-700">
              {(t.includes as string[] | null)?.map((it, i) => <li key={i}>{it}</li>) || <li>Details available on request.</li>}
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-xl">What's excluded</h3>
            <ul className="mt-2 grid gap-1 list-disc pl-5 text-stone-700">
              {(t.excludes as string[] | null)?.map((it, i) => <li key={i}>{it}</li>) || <li>Details available on request.</li>}
            </ul>
          </div>
        </article>
        <aside className="grid gap-4">
          <div className="card p-5">
            <h4 className="font-semibold">Availability & Booking</h4>
            <p className="mt-2 text-sm text-stone-700">Prices shown are examples until confirmed. Ask us about availability for your dates.</p>
            <div className="mt-3 grid gap-2">
              <Link href={`/trip-planner?tour=${encodeURIComponent(t.slug)}`} className="btn-primary">Book This Tour</Link>
              <Link href={`/contact`} className="btn-secondary">Contact Us</Link>
            </div>
          </div>
        </aside>
      </section>

      <Footer />
    </main>
  );
}
