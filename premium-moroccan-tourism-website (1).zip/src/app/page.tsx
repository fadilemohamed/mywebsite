import { sql } from "drizzle-orm";
import { db } from "@/db";
import { destinations, testimonials, tours } from "@/db/schema";
import { Hero } from "@/components/site/Hero";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { DestinationCard } from "@/components/site/DestinationCard";
import { TourCard } from "@/components/site/TourCard";

import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  await db.execute(sql`select 1`);
  await ensureSeeded();

  const [destRows, tourRows, reviewRows] = await Promise.all([
    db.select().from(destinations).limit(6),
    db.select().from(tours).limit(6),
    db.select().from(testimonials).limit(6),
  ]);

  return (
    <main className="body-gradient">
      <Navbar />
      <Hero />

      {/* Featured Destinations */}
      <section className="mx-auto container-max px-6 py-16">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className="badge">Top Destinations</p>
            <h2 className="h2 mt-2 text-3xl md:text-4xl font-semibold">Where to next?</h2>
          </div>
          <a href="/destinations" className="btn-secondary">View all</a>
        </div>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {destRows.map((d) => (
            <DestinationCard key={d.slug} d={d as any} />
          ))}
        </div>
      </section>

      {/* Popular Tours */}
      <section className="mx-auto container-max px-6 py-16">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className="badge">Popular Tours</p>
            <h2 className="h2 mt-2 text-3xl md:text-4xl font-semibold">Handpicked experiences</h2>
          </div>
          <a href="/tours" className="btn-secondary">Browse all</a>
        </div>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {tourRows.map((t) => (
            <TourCard key={t.slug} t={t as any} />
          ))}
        </div>
      </section>

      {/* Why choose us */}
      <section className="mx-auto container-max px-6 py-16">
        <div className="card p-8">
          <div className="grid md:grid-cols-3 gap-8 items-start">
            <div>
              <h2 className="h2 text-3xl font-semibold">Why choose us</h2>
              <p className="mt-2 text-stone-700">Local knowledge, personalized service, and a commitment to responsible tourism. We design safe, authentic, and unforgettable Moroccan experiences.</p>
            </div>
            <ul className="grid gap-4">
              <li className="flex items-start gap-3"><span className="badge">Tailor-made</span><span>Personalized itineraries built around your interests and schedule.</span></li>
              <li className="flex items-start gap-3"><span className="badge">Trusted</span><span>Professional guides, reliable transport, and clear communication.</span></li>
              <li className="flex items-start gap-3"><span className="badge">Authentic</span><span>Real cultural encounters with genuine Moroccan hospitality.</span></li>
            </ul>
            <ul className="grid gap-4">
              <li className="flex items-start gap-3"><span className="badge">Flexible</span><span>Private or group options in multiple languages.</span></li>
              <li className="flex items-start gap-3"><span className="badge">Support</span><span>End-to-end assistance from planning to your final day.</span></li>
              <li className="flex items-start gap-3"><span className="badge">Responsible</span><span>We prioritize local communities and the environment.</span></li>
            </ul>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="mx-auto container-max px-6 py-16">
        <p className="badge">Customer Reviews</p>
        <h2 className="h2 mt-2 text-3xl md:text-4xl font-semibold">What travelers say</h2>
        <div className="mt-8 grid gap-5 md:grid-cols-3">
          {reviewRows.map((r, i) => (
            <div key={i} className="card p-6">
              <div className="flex items-center gap-2 text-terracotta-600">{"★★★★★".slice(0, r.rating || 5)}</div>
              <p className="mt-3 text-stone-800">{r.content} <span className="text-xs text-stone-500">(placeholder)</span></p>
              <p className="mt-4 text-sm text-stone-600">— {r.name} {r.country ? `• ${r.country}` : ""}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Contact CTA */}
      <section className="mx-auto container-max px-6 pb-24">
        <div className="relative overflow-hidden rounded-3xl bg-oasis-700 p-8 text-white">
          <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "url(/images/pattern-moroccan.png)", backgroundSize: "400px" }} />
          <div className="relative z-10 grid gap-4 md:grid-cols-2 items-center">
            <div>
              <h3 className="h2 text-3xl font-semibold">Ready to plan your Moroccan adventure?</h3>
              <p className="mt-2 text-white/90">Tell us what you love — we will craft a personalized itinerary.</p>
            </div>
            <div className="flex flex-wrap items-center gap-3 md:justify-end">
              <a href="/trip-planner" className="btn-secondary bg-white text-desert-700">Plan Your Trip</a>
              <a href="/contact" className="btn-secondary">Contact Us</a>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
