import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { CustomTripPlannerForm } from "@/components/forms/CustomTripPlannerForm";
import { Suspense } from "react";

export default function TripPlannerPage() {
  return (
    <main className="body-gradient min-h-dvh">
      <Navbar />
      <section className="mx-auto container-max px-6 py-12">
        <h1 className="h2 text-4xl font-semibold">Custom Trip Planner</h1>
        <p className="mt-2 text-stone-700 max-w-2xl">Select your dates, destinations, and preferences. We'll design a personalized Moroccan itinerary. Placeholder content until business details are provided.</p>
        <div className="mt-8">
          <Suspense fallback={<div className="text-stone-600">Loading form…</div>}>
            <CustomTripPlannerForm />
          </Suspense>
        </div>
      </section>
      <Footer />
    </main>
  );
}
