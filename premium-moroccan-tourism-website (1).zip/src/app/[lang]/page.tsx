import { notFound } from "next/navigation";
import HomePage from "../page";

export default async function I18nHome({ params }: { params: { lang: string } }) {
  const supported = ["en", "fr", "es", "de"];
  const lang = params.lang.toLowerCase();
  if (!supported.includes(lang)) return notFound();
  // For now, we render the English content. This route prepares the architecture for future translations.
  return HomePage();
}
