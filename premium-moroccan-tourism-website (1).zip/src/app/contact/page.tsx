import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import Link from "next/link";

export const metadata = {
  title: "Contact & Booking",
  description: "Inquire via WhatsApp or email. Request availability and start planning your trip.",
};

export default function ContactPage() {
  const waNumber = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "0000000000";
  const waLink = `https://wa.me/${waNumber}?text=${encodeURIComponent("Hi! I'd like to plan a trip to Morocco.")}`;
  return (
    <main className="body-gradient min-h-dvh">
      <Navbar />
      <section className="mx-auto container-max px-6 py-12 grid gap-8 md:grid-cols-2">
        <div>
          <h1 className="h2 text-4xl font-semibold">Contact & Booking</h1>
          <p className="mt-2 text-stone-700">We'd love to help you plan your Moroccan adventure. Prices and availability are confirmed upon inquiry.</p>

          <div className="mt-6 grid gap-3">
            <a className="btn-primary inline-flex w-max" href={waLink} target="_blank">Chat on WhatsApp</a>
            <a className="btn-secondary inline-flex w-max" href="mailto:contact@example.com">Email Us (placeholder)</a>
            <Link className="btn-secondary inline-flex w-max" href="/trip-planner">Custom Trip Planner</Link>
          </div>

          <div className="mt-8 text-sm text-stone-700">
            <p><strong>Business location:</strong> Pending</p>
            <p><strong>Social media:</strong> Links to be provided</p>
          </div>
        </div>
        <form className="card p-6 grid gap-4" action="/api/inquiry" method="post">
          <h3 className="font-semibold text-xl">Quick Inquiry</h3>
          <input className="rounded-xl border px-3 py-2" required name="fullName" placeholder="Full name" />
          <input className="rounded-xl border px-3 py-2" required type="email" name="email" placeholder="Email" />
          <input className="rounded-xl border px-3 py-2" name="phone" placeholder="Phone (optional)" />
          <textarea className="rounded-xl border px-3 py-2 min-h-28" name="additional" placeholder="Tell us about your plans" />
          <button className="btn-primary" type="submit">Send Inquiry</button>
          <p className="text-xs text-stone-600">We will get back to you as soon as possible.</p>
        </form>
      </section>
      <Footer />
    </main>
  );
}
