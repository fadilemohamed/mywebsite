import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";

export const metadata = {
  title: "About Us",
  description: "Our story, local knowledge, and commitment to authentic Moroccan hospitality.",
};

export default function AboutPage() {
  return (
    <main className="body-gradient min-h-dvh">
      <Navbar />
      <section className="mx-auto container-max px-6 py-12 grid gap-8 md:grid-cols-2">
        <div>
          <h1 className="h2 text-4xl font-semibold">About Morocco Journeys</h1>
          <p className="mt-4 text-stone-800">
            We specialize in crafting premium, authentic, and safe travel experiences across Morocco for international visitors. Our team combines local knowledge with personalized service to design itineraries that match your interests, timeline, and comfort.
          </p>
          <p className="mt-3 text-stone-800">
            We believe in responsible tourism — supporting local communities and preserving cultural heritage. All details on this page are placeholders until the business provides its official information. We do not claim awards, certifications, or years of experience.
          </p>
        </div>
        <div className="card p-6">
          <h3 className="font-semibold text-xl">Our values</h3>
          <ul className="mt-3 grid gap-3 text-stone-700">
            <li>Personalization and attention to detail</li>
            <li>Safety and transparent communication</li>
            <li>Authentic cultural experiences</li>
            <li>Respect for local communities and environment</li>
          </ul>
        </div>
      </section>
      <Footer />
    </main>
  );
}
