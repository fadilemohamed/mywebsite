import { db } from "@/db";
import { testimonials } from "@/db/schema";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";

export const dynamic = "force-dynamic";

export default async function ReviewsPage() {
  const rows = await db.select().from(testimonials);
  return (
    <main className="body-gradient min-h-dvh">
      <Navbar />
      <section className="mx-auto container-max px-6 py-12">
        <h1 className="h2 text-4xl font-semibold">Customer Reviews</h1>
        <p className="mt-2 text-stone-700">The testimonials below are placeholders until genuine reviews are available.</p>
        <div className="mt-8 grid gap-5 md:grid-cols-3">
          {rows.map((r, i) => (
            <div key={i} className="card p-6">
              <div className="flex items-center gap-2 text-terracotta-600">{"★★★★★".slice(0, r.rating || 5)}</div>
              <p className="mt-3 text-stone-800">{r.content} <span className="text-xs text-stone-500">(placeholder)</span></p>
              <p className="mt-4 text-sm text-stone-600">— {r.name} {r.country ? `• ${r.country}` : ""}</p>
            </div>
          ))}
        </div>
      </section>
      <Footer />
    </main>
  );
}
