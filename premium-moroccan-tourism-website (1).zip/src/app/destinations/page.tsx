import { db } from "@/db";
import { destinations } from "@/db/schema";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { DestinationCard } from "@/components/site/DestinationCard";


export const dynamic = "force-dynamic";

export default async function DestinationsPage() {
  const rows = await db.select().from(destinations);
  return (
    <main className="body-gradient min-h-dvh">
      <Navbar />
      <section className="mx-auto container-max px-6 py-12">
        <h1 className="h2 text-4xl font-semibold">Destinations</h1>
        <p className="mt-2 text-stone-700">Explore Morocco's iconic cities, deserts, mountains, and coasts.</p>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {rows.map((d) => (
            <DestinationCard key={d.slug} d={d as any} />
          ))}
        </div>
      </section>
      <Footer />
    </main>
  );
}
