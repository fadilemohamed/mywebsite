import { db } from "@/db";
import { destinations, tours } from "@/db/schema";
import { eq } from "drizzle-orm";
import Image from "next/image";
import Link from "next/link";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { TourCard } from "@/components/site/TourCard";

export const dynamic = "force-dynamic";

export default async function DestinationDetail({ params }: { params: { slug: string } }) {
  const [d] = await db.select().from(destinations).where(eq(destinations.slug, params.slug)).limit(1);
  if (!d) {
    return (
      <main>
        <Navbar />
        <div className="mx-auto container-max px-6 py-20">
          <h1 className="h2 text-3xl font-semibold">Destination not found</h1>
          <p className="mt-2">This page is not available.</p>
        </div>
        <Footer />
      </main>
    );
  }

  const toursForDest = await db.select().from(tours).where(eq(tours.destinationSlug, d.slug));

  return (
    <main className="min-h-dvh body-gradient">
      <Navbar />
      <section className="relative h-[40svh]">
        <Image src={d.mainImage || "/images/marrakech-medina.jpg"} alt={d.name} fill className="object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-black/10" />
        <div className="relative z-10 mx-auto container-max px-6 h-full flex items-end pb-8">
          <div>
            <h1 className="h1 text-4xl md:text-5xl font-bold text-white">{d.name}</h1>
            {d.shortDescription && <p className="mt-2 max-w-2xl text-white/90">{d.shortDescription}</p>}
          </div>
        </div>
      </section>

      <section className="mx-auto container-max px-6 py-12 grid gap-12 md:grid-cols-3">
        <div className="md:col-span-2 grid gap-6">
          {d.description && <p className="text-stone-800 text-lg">{d.description}</p>}
          {Array.isArray(d.attractions) && d.attractions.length > 0 && (
            <div>
              <h3 className="font-semibold text-xl">Top attractions</h3>
              <ul className="mt-2 grid list-disc gap-1 pl-5 text-stone-700">
                {d.attractions.map((a, i) => (
                  <li key={i}>{a}</li>
                ))}
              </ul>
            </div>
          )}
          {Array.isArray(d.activities) && d.activities.length > 0 && (
            <div>
              <h3 className="font-semibold text-xl">Suggested activities</h3>
              <ul className="mt-2 grid list-disc gap-1 pl-5 text-stone-700">
                {d.activities.map((a, i) => (
                  <li key={i}>{a}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
        <aside className="grid gap-4">
          <div className="card p-5">
            <h4 className="font-semibold">Plan your trip</h4>
            <p className="mt-2 text-sm text-stone-700">Tell us what you'd like to see in {d.name}, and we'll design a bespoke itinerary.</p>
            <Link href={`/trip-planner?destinations=${encodeURIComponent(d.slug)}`} className="btn-primary mt-3">Start Planning</Link>
          </div>
        </aside>
      </section>

      {toursForDest.length > 0 && (
        <section className="mx-auto container-max px-6 pb-16">
          <h3 className="h2 text-3xl font-semibold">Tours in {d.name}</h3>
          <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {toursForDest.map((t) => (
              <TourCard key={t.slug} t={t as any} />
            ))}
          </div>
        </section>
      )}

      <Footer />
    </main>
  );
}
