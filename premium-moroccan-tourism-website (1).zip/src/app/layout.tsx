import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://example.com"),
  title: {
    default: "Morocco Journeys — Premium Private & Group Tours",
    template: "%s | Morocco Journeys",
  },
  description:
    "Authentic journeys, unforgettable experiences, and personalized adventures across Morocco. Private and group tours to Marrakech, Sahara Desert, Atlas Mountains, Fes, Chefchaouen, and more.",
  keywords: [
    "Morocco travel agency",
    "Morocco private tours",
    "Sahara Desert trips",
    "Marrakech excursions",
    "Atlas Mountains tour",
  ],
  openGraph: {
    title: "Morocco Journeys — Premium Private & Group Tours",
    description:
      "Authentic journeys, unforgettable experiences, and personalized adventures across Morocco.",
    url: "/",
    siteName: "Morocco Journeys",
    images: [{ url: "/images/hero-desert.jpg", width: 1200, height: 630 }],
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Morocco Journeys — Premium Private & Group Tours",
    description:
      "Authentic journeys, unforgettable experiences, and personalized adventures across Morocco.",
    images: ["/images/hero-desert.jpg"],
  },
};

import { Inter, Playfair_Display } from "next/font/google";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const playfair = Playfair_Display({ subsets: ["latin"], variable: "--font-playfair" });

import { FloatingWhatsAppButton } from "@/components/site/FloatingWhatsAppButton";

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="scroll-smooth">
      <body
        className={`${inter.variable} ${playfair.variable} bg-sand-50 text-stone-900 antialiased min-h-dvh`}
      >
        {children}
        <FloatingWhatsAppButton />
      </body>
    </html>
  );
}
