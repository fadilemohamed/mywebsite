// Keep the schema entrypoint present so models can define tables and run
// `npx drizzle-kit push` without bootstrapping Drizzle config first.
import { pgTable, serial, text, varchar, integer, boolean, timestamp, date, jsonb } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const destinations = pgTable("destinations", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 120 }).notNull().unique(),
  name: varchar("name", { length: 200 }).notNull(),
  shortDescription: text("short_description"),
  description: text("description"),
  mainImage: text("main_image"),
  gallery: jsonb("gallery").$type<string[] | null>().default(sql`NULL`),
  attractions: jsonb("attractions").$type<string[] | null>().default(sql`NULL`),
  activities: jsonb("activities").$type<string[] | null>().default(sql`NULL`),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
});

export const tours = pgTable("tours", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 140 }).notNull().unique(),
  name: varchar("name", { length: 200 }).notNull(),
  destinationSlug: varchar("destination_slug", { length: 120 }).notNull(),
  durationDays: integer("duration_days").notNull(),
  startingPrice: integer("starting_price"),
  isGroup: boolean("is_group").default(false).notNull(),
  isPrivate: boolean("is_private").default(true).notNull(),
  languages: jsonb("languages").$type<string[] | null>().default(sql`NULL`),
  includes: jsonb("includes").$type<string[] | null>().default(sql`NULL`),
  excludes: jsonb("excludes").$type<string[] | null>().default(sql`NULL`),
  highlights: jsonb("highlights").$type<string[] | null>().default(sql`NULL`),
  itinerary: jsonb("itinerary").$type<{ day: number; title: string; details: string }[] | null>().default(sql`NULL`),
  mainImage: text("main_image"),
  gallery: jsonb("gallery").$type<string[] | null>().default(sql`NULL`),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
});

export const testimonials = pgTable("testimonials", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  country: varchar("country", { length: 120 }),
  rating: integer("rating").default(5).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
});

export const inquiries = pgTable("inquiries", {
  id: serial("id").primaryKey(),
  fullName: varchar("full_name", { length: 200 }).notNull(),
  email: varchar("email", { length: 200 }).notNull(),
  phone: varchar("phone", { length: 60 }),
  whatsapp: varchar("whatsapp", { length: 60 }),
  startDate: date("start_date"),
  endDate: date("end_date"),
  travelers: integer("travelers").default(2),
  destinations: jsonb("destinations").$type<string[] | null>().default(sql`NULL`),
  activities: jsonb("activities").$type<string[] | null>().default(sql`NULL`),
  budgetRange: varchar("budget_range", { length: 120 }),
  groupType: varchar("group_type", { length: 40 }),
  language: varchar("language", { length: 60 }),
  additional: text("additional"),
  tourId: integer("tour_id"),
  source: varchar("source", { length: 120 }),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
});

