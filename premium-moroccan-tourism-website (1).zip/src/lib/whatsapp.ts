export function buildWhatsAppLink(opts: { phone?: string; text: string }) {
  const phone = opts.phone?.replace(/\D/g, "") || process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "0000000000";
  const text = encodeURIComponent(opts.text);
  return `https://wa.me/${phone}?text=${text}`;
}
