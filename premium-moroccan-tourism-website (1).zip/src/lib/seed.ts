import { db } from "@/db";
import { destinations, testimonials, tours } from "@/db/schema";
import { and, count, eq } from "drizzle-orm";

export async function ensureSeeded() {
  const destCount = await db.select({ c: count() }).from(destinations);
  if ((destCount[0]?.c || 0) === 0) {
    await db.insert(destinations).values([
      {
        slug: "marrakech",
        name: "Marrakech",
        shortDescription: "Vibrant souks, gardens, palaces, and legendary Jemaa el-Fnaa.",
        mainImage: "/images/marrakech-medina.jpg",
        gallery: [
          "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?q=80&w=1600&auto=format&fit=crop",
          "https://images.unsplash.com/photo-1607863681918-3ce34d489a03?q=80&w=1600&auto=format&fit=crop",
        ],
        attractions: ["Jemaa el-Fnaa", "Majorelle Garden", "Koutoubia Mosque"],
        activities: ["Guided medina tour", "Cooking class", "Hammam & spa"],
      },
      {
        slug: "sahara-desert",
        name: "Sahara Desert & Merzouga",
        shortDescription: "Golden dunes, camel caravans, and starry desert nights.",
        mainImage: "/images/hero-desert.jpg",
        gallery: [
          "https://images.unsplash.com/photo-1503924087716-07cbd5f49b21?q=80&w=1600&auto=format&fit=crop",
        ],
        attractions: ["Erg Chebbi dunes", "Merzouga", "Desert camp"],
        activities: ["Camel trek", "4x4 desert tour", "Sandboarding"],
      },
      {
        slug: "fes",
        name: "Fes",
        shortDescription: "Ancient medina, artisan workshops, and cultural heritage.",
        mainImage: "https://images.unsplash.com/photo-1576426863848-0c4fefd4a573?q=80&w=1600&auto=format&fit=crop",
        gallery: [],
        attractions: ["Fes el-Bali", "Chouara Tannery", "Bou Inania"],
        activities: ["Guided medina tour", "Ceramic workshop", "Food tour"],
      },
      { slug: "chefchaouen", name: "Chefchaouen", shortDescription: "The Blue City in the Rif Mountains.", mainImage: "https://images.unsplash.com/photo-1530023367847-a683933f4171?q=80&w=1600&auto=format&fit=crop" },
      { slug: "casablanca", name: "Casablanca", shortDescription: "Modern heartbeat and Hassan II Mosque.", mainImage: "https://images.unsplash.com/photo-1526413232649-65d7321f0dc7?q=80&w=1600&auto=format&fit=crop" },
      { slug: "essaouira", name: "Essaouira", shortDescription: "Coastal charm, ramparts, and seafood.", mainImage: "https://images.unsplash.com/photo-1533105079780-92b9be482077?q=80&w=1600&auto=format&fit=crop" },
      { slug: "agadir", name: "Agadir", shortDescription: "Beach resort city with year-round sun.", mainImage: "https://images.unsplash.com/photo-1543263320-66cd17d18b74?q=80&w=1600&auto=format&fit=crop" },
      { slug: "atlas-mountains", name: "Atlas Mountains", shortDescription: "Berber villages and epic hiking routes.", mainImage: "https://images.unsplash.com/photo-1533636721434-0e2d61030955?q=80&w=1600&auto=format&fit=crop" },
      { slug: "ouarzazate-ait-benhaddou", name: "Ouarzazate & Ait Ben Haddou", shortDescription: "Desert gateways and film studios.", mainImage: "https://images.unsplash.com/photo-1571601035751-0a5637eab7ce?q=80&w=1600&auto=format&fit=crop" },
    ]);
  }

  const tourCount = await db.select({ c: count() }).from(tours);
  if ((tourCount[0]?.c || 0) === 0) {
    await db.insert(tours).values([
      {
        slug: "marrakech-city-highlights",
        name: "Marrakech City Highlights",
        destinationSlug: "marrakech",
        durationDays: 1,
        startingPrice: 120,
        isGroup: true,
        isPrivate: true,
        languages: ["English", "French", "Spanish"],
        includes: ["Guide", "Entrance fees", "Hotel pickup"],
        excludes: ["Lunch", "Tips"],
        highlights: ["Jemaa el-Fnaa", "Bahia Palace", "Medina"],
        itinerary: [
          { day: 1, title: "Guided Tour", details: "Meet your guide and explore key sights and hidden gems." },
        ],
        mainImage: "/images/marrakech-medina.jpg",
        gallery: [
          "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?q=80&w=1600&auto=format&fit=crop",
        ],
      },
      {
        slug: "merzouga-sahara-3d2n",
        name: "Merzouga Sahara Desert (3D/2N)",
        destinationSlug: "sahara-desert",
        durationDays: 3,
        startingPrice: 480,
        isGroup: true,
        isPrivate: true,
        languages: ["English", "French", "Spanish", "German"],
        includes: ["Transport", "Camel trek", "Desert camp", "Breakfast & Dinner"],
        excludes: ["Lunch", "Drinks"],
        highlights: ["Erg Chebbi", "Camel Caravan", "Sunrise on dunes"],
        itinerary: [
          { day: 1, title: "Marrakech → Dades", details: "Drive via Atlas Mountains and Ait Ben Haddou." },
          { day: 2, title: "Dades → Merzouga", details: "Camel trek and night in desert camp." },
          { day: 3, title: "Merzouga → Marrakech", details: "Return via scenic route." },
        ],
        mainImage: "/images/hero-desert.jpg",
        gallery: [
          "https://images.unsplash.com/photo-1503924087716-07cbd5f49b21?q=80&w=1600&auto=format&fit=crop",
        ],
      },
      {
        slug: "atlas-mountains-day-trip",
        name: "Atlas Mountains Day Trip",
        destinationSlug: "atlas-mountains",
        durationDays: 1,
        startingPrice: 150,
        isGroup: true,
        isPrivate: true,
        languages: ["English", "French"],
        includes: ["Transport", "Guide"],
        excludes: ["Lunch"],
        highlights: ["Imlil", "Berber Village", "Waterfall walk"],
        itinerary: [
          { day: 1, title: "Mountain Adventure", details: "Scenic drive and guided village walk." },
        ],
        mainImage: "https://images.unsplash.com/photo-1533636721434-0e2d61030955?q=80&w=1600&auto=format&fit=crop",
      },
    ]);
  }

  const testCount = await db.select({ c: count() }).from(testimonials);
  if ((testCount[0]?.c || 0) === 0) {
    await db.insert(testimonials).values([
      { name: "Anna (placeholder)", country: "Germany", rating: 5, content: "An unforgettable journey through Morocco — highly recommended!" },
      { name: "James (placeholder)", country: "USA", rating: 5, content: "Professional, friendly, and truly authentic experiences." },
      { name: "Sophie (placeholder)", country: "UK", rating: 5, content: "Felt safe and cared for from start to finish." },
    ]);
  }
}
