"use client";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useSearchParams } from "next/navigation";
import { useState } from "react";
import { Button } from "@/components/ui/Button";

const schema = z.object({
  fullName: z.string().min(2),
  email: z.string().email(),
  phone: z.string().optional(),
  whatsapp: z.string().optional(),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
  travelers: z.coerce.number().min(1),
  destinations: z.array(z.string()).optional(),
  activities: z.array(z.string()).optional(),
  budgetRange: z.string().optional(),
  groupType: z.enum(["private", "group"]).optional(),
  language: z.string().optional(),
  additional: z.string().optional(),
  tour: z.string().optional(),
});

export type TripPlannerFormValues = z.infer<typeof schema>;

const DESTS = [
  "Marrakech",
  "Sahara Desert & Merzouga",
  "Fes",
  "Chefchaouen",
  "Casablanca",
  "Essaouira",
  "Atlas Mountains",
  "Ouarzazate & Ait Ben Haddou",
  "Agadir",
];
const ACTIVITIES = ["Culture", "Food & Cooking", "Desert", "Mountains", "Surfing", "Museums", "Shopping"];

export function CustomTripPlannerForm() {
  const params = useSearchParams();
  const defaultTour = params.get("tour") || undefined;
  const defaultDest = params.get("destinations")?.split(",") || [];
  const [submitted, setSubmitted] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<TripPlannerFormValues>({ resolver: zodResolver(schema), defaultValues: { travelers: 2, tour: defaultTour, destinations: defaultDest } });

  const onSubmit = async (data: TripPlannerFormValues) => {
    const res = await fetch("/api/inquiry", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
    if (res.ok) setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="card p-6">
        <h3 className="text-xl font-semibold">Thank you! 🎉</h3>
        <p className="mt-2 text-stone-700">We've received your request. We'll email you shortly. For a faster response, you can also message us on WhatsApp.</p>
        <a className="btn-primary mt-4 inline-block" href={
          `https://wa.me/${process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "0000000000"}?text=${encodeURIComponent("Hi! I just submitted a trip request on your website.")}`
        } target="_blank">Chat on WhatsApp</a>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="card p-6 grid gap-5">
      <div className="grid md:grid-cols-2 gap-4">
        <label className="grid gap-1 text-sm">
          <span>Full name</span>
          <input className="rounded-xl border px-3 py-2" {...register("fullName")} />
          {errors.fullName && <span className="text-red-600 text-xs">Full name is required</span>}
        </label>
        <label className="grid gap-1 text-sm">
          <span>Email</span>
          <input className="rounded-xl border px-3 py-2" type="email" {...register("email")} />
          {errors.email && <span className="text-red-600 text-xs">Valid email is required</span>}
        </label>
      </div>
      <div className="grid md:grid-cols-3 gap-4">
        <label className="grid gap-1 text-sm">
          <span>Phone (optional)</span>
          <input className="rounded-xl border px-3 py-2" {...register("phone")} />
        </label>
        <label className="grid gap-1 text-sm">
          <span>WhatsApp (optional)</span>
          <input className="rounded-xl border px-3 py-2" {...register("whatsapp")} />
        </label>
        <label className="grid gap-1 text-sm">
          <span>Preferred language</span>
          <input className="rounded-xl border px-3 py-2" placeholder="English" {...register("language")} />
        </label>
      </div>
      <div className="grid md:grid-cols-3 gap-4">
        <label className="grid gap-1 text-sm">
          <span>Arrival date</span>
          <input className="rounded-xl border px-3 py-2" type="date" {...register("startDate")} />
        </label>
        <label className="grid gap-1 text-sm">
          <span>Departure date</span>
          <input className="rounded-xl border px-3 py-2" type="date" {...register("endDate")} />
        </label>
        <label className="grid gap-1 text-sm">
          <span>Travelers</span>
          <input className="rounded-xl border px-3 py-2" type="number" min={1} {...register("travelers")} />
        </label>
      </div>
      <div className="grid md:grid-cols-2 gap-4">
        <label className="grid gap-1 text-sm">
          <span>Destinations</span>
          <select multiple className="rounded-xl border px-3 py-2 h-28" {...register("destinations")}> 
            {DESTS.map((d) => <option key={d} value={d.toLowerCase().replace(/\s+/g, "-")}>{d}</option>)}
          </select>
        </label>
        <label className="grid gap-1 text-sm">
          <span>Preferred activities</span>
          <select multiple className="rounded-xl border px-3 py-2 h-28" {...register("activities")}>
            {ACTIVITIES.map((a) => <option key={a} value={a}>{a}</option>)}
          </select>
        </label>
      </div>
      <div className="grid md:grid-cols-3 gap-4">
        <label className="grid gap-1 text-sm">
          <span>Budget range</span>
          <select className="rounded-xl border px-3 py-2" {...register("budgetRange")}>
            <option value="">Select</option>
            <option>€1000–€2000</option>
            <option>€2000–€4000</option>
            <option>€4000+</option>
          </select>
        </label>
        <label className="grid gap-1 text-sm">
          <span>Private or group</span>
          <select className="rounded-xl border px-3 py-2" {...register("groupType")}>
            <option value="">Select</option>
            <option value="private">Private</option>
            <option value="group">Group</option>
          </select>
        </label>
        <label className="grid gap-1 text-sm">
          <span>Specific tour (optional)</span>
          <input className="rounded-xl border px-3 py-2" placeholder="e.g., merzouga-sahara-3d2n" {...register("tour")} />
        </label>
      </div>
      <label className="grid gap-1 text-sm">
        <span>Additional requests</span>
        <textarea className="rounded-xl border px-3 py-2 min-h-28" placeholder="Tell us more about your ideal trip" {...register("additional")} />
      </label>
      <div className="flex items-center gap-3">
        <Button type="submit" loading={isSubmitting}>Submit Inquiry</Button>
        <span className="text-xs text-stone-600">We typically respond within 24 hours.</span>
      </div>
    </form>
  );
}
