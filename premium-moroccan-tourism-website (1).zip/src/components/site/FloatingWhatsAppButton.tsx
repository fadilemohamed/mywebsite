"use client";
import Link from "next/link";
import { MessageCircle } from "lucide-react";
import { buildWhatsAppLink } from "@/lib/whatsapp";

export function FloatingWhatsAppButton() {
  const link = buildWhatsAppLink({ text: "Hello! I'm interested in planning a trip to Morocco." });
  return (
    <Link
      href={link}
      target="_blank"
      aria-label="Chat on WhatsApp"
      className="fixed bottom-5 right-5 z-50 inline-flex items-center gap-2 rounded-full bg-[#25D366] px-4 py-3 text-white shadow-lg ring-1 ring-black/10 hover:brightness-110"
    >
      <MessageCircle className="size-5" />
      <span className="hidden sm:inline">WhatsApp</span>
    </Link>
  );
}
