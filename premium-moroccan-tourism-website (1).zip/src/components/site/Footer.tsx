import Link from "next/link";
import { Facebook, Instagram, Mail, MapPin, Phone, Youtube } from "lucide-react";

export function Footer() {
  return (
    <footer className="mt-24 border-t border-black/5 bg-sand-100/60">
      <div className="mx-auto container-max px-6 py-12 grid gap-10 md:grid-cols-3">
        <div>
          <h3 className="h2 text-xl font-semibold">Morocco Journeys</h3>
          <p className="mt-3 text-sm text-stone-700 max-w-sm">
            Premium Moroccan travel experiences for international visitors. Tailor-made itineraries, private tours, and authentic adventures.
          </p>
          <div className="mt-4 flex items-center gap-3">
            <Link href="#" className="p-2 rounded-full bg-white ring-1 ring-black/5 hover:bg-white/90" aria-label="Instagram"><Instagram className="size-4"/></Link>
            <Link href="#" className="p-2 rounded-full bg-white ring-1 ring-black/5 hover:bg-white/90" aria-label="Facebook"><Facebook className="size-4"/></Link>
            <Link href="#" className="p-2 rounded-full bg-white ring-1 ring-black/5 hover:bg-white/90" aria-label="YouTube"><Youtube className="size-4"/></Link>
          </div>
        </div>
        <div>
          <h4 className="font-semibold">Contact</h4>
          <ul className="mt-3 grid gap-2 text-sm text-stone-700">
            <li className="flex items-center gap-2"><Mail className="size-4"/> <span>contact@example.com (placeholder)</span></li>
            <li className="flex items-center gap-2"><Phone className="size-4"/> <span>+212 600 000 000 (placeholder)</span></li>
            <li className="flex items-center gap-2"><MapPin className="size-4"/> <span>Business location pending</span></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold">Quick Links</h4>
          <ul className="mt-3 grid gap-2 text-sm">
            <li><Link href="/tours" className="hover:text-terracotta-600">Tours</Link></li>
            <li><Link href="/destinations" className="hover:text-terracotta-600">Destinations</Link></li>
            <li><Link href="/trip-planner" className="hover:text-terracotta-600">Plan Your Trip</Link></li>
            <li><Link href="/about" className="hover:text-terracotta-600">About Us</Link></li>
            <li><Link href="/contact" className="hover:text-terracotta-600">Contact & Booking</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-black/5 py-6 text-center text-xs text-stone-600">
        © {new Date().getFullYear()} Morocco Journeys. Placeholder content until business details are provided.
      </div>
    </footer>
  );
}
