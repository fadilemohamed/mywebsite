import Image from "next/image";
import Link from "next/link";
import { formatPriceEUR } from "@/lib/utils";

export type Tour = {
  slug: string;
  name: string;
  destinationSlug: string;
  durationDays: number;
  startingPrice?: number | null;
  mainImage?: string | null;
};

export function TourCard({ t }: { t: Tour }) {
  return (
    <div className="overflow-hidden rounded-3xl ring-1 ring-black/5 bg-white flex flex-col">
      <div className="relative aspect-[4/3]">
        <Image src={t.mainImage || "/images/marrakech-medina.jpg"} alt={t.name} fill className="object-cover" />
      </div>
      <div className="p-5 grid gap-2">
        <h3 className="font-semibold text-lg">{t.name}</h3>
        <p className="text-sm text-stone-600">{t.durationDays} days • From {formatPriceEUR(t.startingPrice)}</p>
        <div className="mt-2 flex gap-2">
          <Link href={`/tours/${t.slug}`} className="btn-primary">View Details</Link>
          <Link href={`/trip-planner?tour=${encodeURIComponent(t.slug)}`} className="btn-secondary">Book This Tour</Link>
        </div>
      </div>
    </div>
  );
}
