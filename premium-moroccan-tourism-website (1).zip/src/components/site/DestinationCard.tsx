import Image from "next/image";
import Link from "next/link";

export type Destination = {
  slug: string;
  name: string;
  shortDescription?: string | null;
  mainImage?: string | null;
};

export function DestinationCard({ d }: { d: Destination }) {
  return (
    <Link href={`/destinations/${d.slug}`} className="group overflow-hidden rounded-3xl ring-1 ring-black/5 bg-white">
      <div className="relative aspect-[4/3]">
        <Image
          src={d.mainImage || "/images/marrakech-medina.jpg"}
          alt={d.name}
          fill
          className="object-cover transition duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
        <div className="absolute bottom-3 left-3 right-3 text-white">
          <h3 className="text-lg font-semibold drop-shadow">{d.name}</h3>
          {d.shortDescription && (
            <p className="text-xs/5 text-white/90 line-clamp-2">{d.shortDescription}</p>
          )}
        </div>
      </div>
    </Link>
  );
}
