"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, X } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

const links = [
  { href: "/tours", label: "Tours" },
  { href: "/destinations", label: "Destinations" },
  { href: "/trip-planner", label: "Plan Your Trip" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
];

export function Navbar() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-black/5 bg-white/70 backdrop-blur">
      <div className="mx-auto container-max px-6">
        <div className="flex h-16 items-center justify-between gap-4">
          <Link href="/" className="flex items-center gap-2">
            <span className="h-8 w-8 rounded-xl bg-terracotta-600/90" />
            <span className="h2 text-lg font-semibold tracking-tight">Morocco Journeys</span>
          </Link>

          <nav className="hidden md:flex items-center gap-6 text-sm">
            {links.map((l) => (
              <Link key={l.href} href={l.href} className={cn("transition hover:text-terracotta-600", pathname.startsWith(l.href) && "text-terracotta-600 font-medium")}>{l.label}</Link>
            ))}
            <Link href="/trip-planner" className="btn-primary text-sm">Plan Your Trip</Link>
          </nav>

          <button className="md:hidden p-2" onClick={() => setOpen((v) => !v)} aria-label="Toggle menu">
            {open ? <X /> : <Menu />}
          </button>
        </div>
      </div>

      {open && (
        <div className="md:hidden border-t border-black/5 bg-white">
          <div className="mx-auto container-max px-6 py-4 grid gap-2">
            {links.map((l) => (
              <Link key={l.href} href={l.href} className="py-2" onClick={() => setOpen(false)}>
                {l.label}
              </Link>
            ))}
            <Link href="/trip-planner" className="btn-primary" onClick={() => setOpen(false)}>Plan Your Trip</Link>
          </div>
        </div>
      )}
    </header>
  );
}
