import Image from "next/image";
import Link from "next/link";

export function Hero() {
  return (
    <section className="relative min-h-[70svh] overflow-hidden">
      <Image src="/images/hero-desert.jpg" alt="Sahara Desert dunes in Morocco" fill priority className="object-cover" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-black/20 to-transparent" />
      <div className="relative z-10 mx-auto container-max px-6 py-24 md:py-36">
        <p className="badge">Premium Moroccan Travel</p>
        <h1 className="h1 mt-4 max-w-2xl text-4xl md:text-6xl font-bold text-white leading-tight">
          Discover the Magic of Morocco
        </h1>
        <p className="mt-4 max-w-2xl text-white/90 text-lg">
          Authentic journeys, unforgettable experiences, and personalized adventures across Morocco.
        </p>
        <div className="mt-8 flex flex-wrap items-center gap-3">
          <Link href="/tours" className="btn-primary">Explore Our Tours</Link>
          <Link href="/trip-planner" className="btn-secondary">Plan Your Trip</Link>
        </div>
      </div>
    </section>
  );
}
